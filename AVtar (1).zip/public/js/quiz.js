import {io} from 'socket.io-client'

const messageInput = 