module.exports = {
    mongoUrl :'mongodb+srv://aman4814be:abcdef123@cluster0.stg8k1w.mongodb.net/avtar'
}